import {useState} from "react"

function useInput(country) {

    const [saved, setSaved] = useState(JSON.parse(localStorage.getItem('saved')) || [])
    const [checked, setChecked] = useState(changes)


    function changes() { 
        if (saved.length > 0 && saved.filter(item => item.name.common === country.name.common).length > 0) {return true}
        else { return false}
    }

    function updatingSaved() {
        //checked? setChecked(false) : setChecked(true);
 
        if (checked) {
            const reducedList = saved.filter(item => item.name.common !== country.name.common)
            localStorage.setItem('saved', JSON.stringify(reducedList))
            const y = JSON.parse(localStorage.getItem('saved'))
            setSaved(y)
            setChecked(false)

        }  else {
            const increasedList = [...saved, country]
            localStorage.setItem('saved', JSON.stringify(increasedList))
            const x = JSON.parse(localStorage.getItem('saved'))
            setSaved(x)
            setChecked(true)
        }}
       
    return [checked, updatingSaved]
}

export default useInput
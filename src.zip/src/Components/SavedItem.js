import React, { useState, useContext } from "react"
import reactStringReplace from 'react-string-replace'
import { v4 as uuidv4 } from 'uuid'
import useInput from "../Hooks/useInput"
import { Context } from "../Context"



function SavedItem({ country, isChecked, id }) {

    const [visited, setVisited] = useState(false)

    const countryName = country.name.common
    const capitalName = country.capital.join(", ") 


    return (
        <div className="suggested-item">
            <input id={id} className="checkbox" type="checkbox" checked={visited} onChange={(e) => setVisited(isChecked(e))}
            />
            {/* {checkedIcon()} */}
            <img className="flag responsive-grid-item" src={country.flags.png} />
            <div> {countryName}</div>
            <div>{capitalName}</div>
            <div className="responsive-grid-item"> {country.languages && Object.values(country.languages).join(', ')}</div>
            <div className="responsive-grid-item"> {country.currencies && Object.keys(country.currencies).join(', ')}</div>
        </div>
    )
}

export default SavedItem


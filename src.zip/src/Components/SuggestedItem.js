import React, { useContext, useState } from "react"
import reactStringReplace from 'react-string-replace'
import { Context } from "../Context"
import { v4 as uuidv4 } from 'uuid'
import useInput from "../Hooks/useInput"

function SuggestedItem({ country, input }) {

    const [checked, updatingSaved] = useInput(country)
    // const { saved, checked, setChecked, setSaved } = useContext(Context)

    // add back in
    // const [saved, setSaved] = useState(JSON.parse(localStorage.getItem('saved')) || [])
    // const [checked, setChecked] = useState(changes)

    
// console.log(changes())
// add back in
    // function changes() { 
    //     if (saved.length > 0 && saved.filter(item => item.name.common === country.name.common).length > 0) {return true}
    //     else { return false}
    // }

    // console.log("saved", saved)

    const countryName = country.name.common && reactStringReplace(country.name.common.toString(), input, (input) => (
        <span key={uuidv4()} className="bold">{input}</span>
    ));
    const capitalName = country.capital && reactStringReplace(country.capital.join(", ").toString(), input, (input) => (
        <span key={uuidv4()} className="bold">{input}</span>
    ));

    // function checkedIcon() {
    //     if (savedCountries.filter(e => e.name.common === country.name.common).length > 0) {
    //         return <div className="check" onClick={() => removeFromSaved(country)}></div>
    //     } else { return <div className="uncheck" onClick={() => addToSaved(country)}></div> }
    // }
// add back in
    // function updatingSaved() {
    //     //checked? setChecked(false) : setChecked(true);
 
    //     if (checked) {
    //         const reducedList = saved.filter(item => item.name.common !== country.name.common)
    //         localStorage.setItem('saved', JSON.stringify(reducedList))
    //         const y = JSON.parse(localStorage.getItem('saved'))
    //         setSaved(y)
    //         setChecked(false)

    //     }  else {
    //         const increasedList = [...saved, country]
    //         localStorage.setItem('saved', JSON.stringify(increasedList))
    //         const x = JSON.parse(localStorage.getItem('saved'))
    //         setSaved(x)
    //         setChecked(true)
    //     }
       
    // }

    return (
        <div className="suggested-item">
            <input className="checkbox" type="checkbox" checked ={checked} onChange={()=> updatingSaved()}/>
            {/* {checkedIcon()} */}
            <img className="flag responsive-grid-item" src={country.flags.png} />
            <div> {countryName}</div>
            <div>{capitalName}</div>
            <div className="responsive-grid-item"> {country.languages && Object.values(country.languages).join(', ')}</div>
            <div className="responsive-grid-item"> {country.currencies && Object.keys(country.currencies).join(', ')}</div>
        </div>
    )
}

export default SuggestedItem


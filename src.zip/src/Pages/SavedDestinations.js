import React, { useContext, useEffect, useState } from "react"
import { v4 as uuidv4 } from 'uuid'
import SavedItem from "../Components/SavedItem"


function SavedDestinations() {

    const saved = JSON.parse(localStorage.getItem("saved")) || []



    const savedItemElements = saved.map((item, index) =>
        (<SavedItem key={uuidv4()} country={item} isChecked={isChecked} id={index} />))

    const inputs = document.querySelectorAll(".checkbox")


    let lastChecked
    // let arr = []
    // let inBetween = false
    let blob

    function isChecked(e, id) {
        let newArray = []
            inputs.forEach((item, index) => newArray.push(index))
            console.log(newArray)

        if (e.shiftKey && e.target.checked) {
            let blob = newArray.slice(
                Math.min(lastChecked, e.target.id),
                Math.max(lastChecked, e.target.id) + 1
            )
            console.log(blob)
        }


        // arr = []
 
      
        lastChecked = e.target.id;
        if (blob && blob.filter(item => item === id).length > 0) {return true} else {return false}
        console.log("lastchecked", lastChecked)
    }



    return (
        <>
            {savedItemElements}
        </>
    )

}

export default SavedDestinations